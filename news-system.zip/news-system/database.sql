

USE `newsmanagersystem`;

/*Table structure for table `news` */

DROP TABLE IF EXISTS `news`;

CREATE TABLE `news` (
  `nid` int(11) NOT NULL AUTO_INCREMENT,
  `ntid` int(11) NOT NULL,
  `ntitle` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `nauthor` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ncreateDate` datetime DEFAULT NULL,
  `npicPath` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ncontent` text COLLATE utf8_unicode_ci NOT NULL,
  `nmodifyDate` datetime DEFAULT NULL,
  `nsummary` varchar(4000) COLLATE utf8_unicode_ci ，
  PRIMARY KEY (`nid`),
  KEY `NEWS_TOPIC` (`ntid`),
  CONSTRAINT `NEWS_TOPIC` FOREIGN KEY (`ntid`) REFERENCES `topic` (`TID`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



/*Table structure for table `news_users` */

DROP TABLE IF EXISTS `news_users`;

CREATE TABLE `news_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `upwd` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `news_users` */

insert  into `news_users`(`uid`,`uname`,`upwd`) values (1,'admin','admin');

/*Table structure for table `topic` */

DROP TABLE IF EXISTS `topic`;

CREATE TABLE `topic` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `tname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `topic` */

insert  into `topic`(`tid`,`tname`) values (1,'国内'),(2,'国际'),(3,'军事'),(4,'体育'),(5,'娱乐'),(6,'社会'),(7,'财经'),(8,'科技'),(9,'健康');

