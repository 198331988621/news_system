package com.gzxh.newssystem;

import com.gzxh.newssystem.dao.NewsMapper;
import com.gzxh.newssystem.dao.TopicMapper;
import com.gzxh.newssystem.entity.News;
import com.gzxh.newssystem.entity.Topic;
import org.apache.ibatis.annotations.Param;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class NewsSystemApplicationTests {
    @Autowired
    NewsMapper newsMapper;
    @Autowired
    TopicMapper topicMapper;
    @Test
    void contextLoads() {
        List<News> list=newsMapper.getNewsListByTopicId(1,2);
        for(News news:list){
            System.out.println(news);
        }
    }
    @Test
    public void updateTopic(){
        Topic topic=new Topic();
        topic.setTid(1);
        topic.setTname("12");
        System.out.println(topicMapper.updateTopic(topic));
    }

}
