package com.gzxh.newssystem.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.gzxh.newssystem.entity.Topic;
import com.gzxh.newssystem.vo.TopicQueryVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TopicMapper extends BaseMapper<Topic> {
}
