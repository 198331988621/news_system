package com.gzxh.newssystem.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.io.Serializable;
@Data
@TableName("news_users")
public class Users implements Serializable {

private static final long serialVersionUID=1L;

    @TableId(value = "uid", type = IdType.AUTO)
    private int uid; //用户编号

    private String uname;//用户账号

    private String upwd;//用户登录密码




    @Override
    public String toString() {
        return "Users{" +
        "uid=" + uid +
        ", uname=" + uname +
        ", upwd=" + upwd +
        "}";
    }
}
