package com.gzxh.newssystem.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gzxh.newssystem.entity.Comments;
import com.gzxh.newssystem.entity.Topic;
import com.gzxh.newssystem.service.CommentsService;
import com.gzxh.newssystem.service.TopicService;
import com.gzxh.newssystem.vo.NewsQueryVo;
import org.apache.commons.io.FilenameUtils;
import org.springframework.ui.Model;
import com.gzxh.newssystem.entity.News;
import com.gzxh.newssystem.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;


@RequestMapping("/news")
@Controller
public class NewsController {
    @Autowired
    NewsService newsService;

    @Autowired
    CommentsService commentsService;

    @Autowired
    TopicService topicService;

    @RequestMapping("/detail/{nid}")
    //@PathVariable("nid") 用来接收路径里面的隐藏变量名的参数
    public String detail(@PathVariable("nid") Integer nid, Model model) {

        List<News> newsList1 = newsService.getNewsListByTopicId(1, 6);
        List<News> newsList2 = newsService.getNewsListByTopicId(2, 6);
        List<News> newsList3 = newsService.getNewsListByTopicId(5, 6);

        model.addAttribute("newsList1",newsList1);
        model.addAttribute("newsList2",newsList2);
        model.addAttribute("newsList3",newsList3);

        News news=newsService.getById(nid);
        model.addAttribute("news",news);

        QueryWrapper<Comments> wrapper=new QueryWrapper<>();
        wrapper.eq("cnid",nid);
        List<Comments> commentsList=commentsService.list(wrapper);
        model.addAttribute("commentsList",commentsList);
        return "news/detail.html";
    }

    @RequestMapping("/manager")
    public String manager(NewsQueryVo newsQueryVo, Model model){

        IPage<News> page = new Page<>(newsQueryVo.getPageNo(),newsQueryVo.getPageSize());

        newsService.getNewsListByPage(page,newsQueryVo);

        model.addAttribute("page",page);
        return "admin";
    }

    @RequestMapping("/deleteById/{nid}")
    public void deleteById(@PathVariable("nid") Integer nid, HttpServletResponse response){
        try {
//            response.setContentType("text/html;charset=utf-8");
            response.setCharacterEncoding("GBK");
            PrintWriter printWriter=response.getWriter();

            if(newsService.deleteById(nid)){
                printWriter.println("<script>"+
                        "alert('删除成功');" +
                        "location.href='/news/manager';" +
                        "</script>");
            }
            else {
                printWriter.println("<script>" +
                        "alert('删除失败');" +
                        "location.href='/news/manager';" +
                        "</script>");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //跳转到添加新闻的页面
    @RequestMapping("/add.html")
    public String addpage(Model model){
        model.addAttribute("topicList", topicService.list());
        return "news/add";
    }
    //添加新闻
    @RequestMapping("/add")
    public String add(News news,MultipartFile file){

        uploadPic(news,file);

        news.setNcreateDate(new Date());

        if(newsService.save(news)){

            return "redirect:/news/manager";
        }
        return "redirect:/news/add.html";
    }

    //修改新闻 获取新闻 根据新闻编号进行修改
    @RequestMapping("/edit/{nid}")
    public String editpage(@PathVariable("nid") Integer nid,Model model){
        //查询新闻分类信息，展示到页面去
        List<Topic> topicsList=topicService.list();
        model.addAttribute("topicList", topicsList);
        //要修改新闻就要获取修改新闻信息
        News news=newsService.getById(nid);
        model.addAttribute("news",news);
        return "news/edit";
    }

    @RequestMapping("/edit")
    public String edit(News news,MultipartFile file){

        uploadPic(news,file);

        news.setNcreateDate(new Date());

        if(newsService.updateById(news)){

            return "redirect:/news/manager";
        }
        return "redirect:/news/edit.html"+news.getNid();
    }


    public void uploadPic(News news,MultipartFile file) {
        try {
            String path = "D:\\"; //上传到D盘

            if (!file.isEmpty()) {

                String originalFilename = file.getOriginalFilename();

                String extension = FilenameUtils.getExtension(originalFilename);

                String newFileName = UUID.randomUUID().toString()
                        .replace("'", "") + "." + extension;

                String dataPath = new SimpleDateFormat("yyyyMMdd").format(new Date());

                String finalName = dataPath + "/" + newFileName;
                System.out.println(finalName);

                File destFile = new File(path, finalName);

                if (!destFile.getParentFile().exists()) {
                    destFile.getParentFile().mkdir();
                }

                file.transferTo(destFile);

                news.setNpicPath(finalName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
