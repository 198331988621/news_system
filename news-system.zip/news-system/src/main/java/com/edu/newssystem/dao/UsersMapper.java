package com.gzxh.newssystem.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gzxh.newssystem.entity.Users;

public interface UsersMapper extends BaseMapper<Users> {
}
