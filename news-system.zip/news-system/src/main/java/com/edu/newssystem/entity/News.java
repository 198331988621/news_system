package com.gzxh.newssystem.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;


@TableName("news")
@Data
public class News implements Serializable {

private static final long serialVersionUID=1L;

    @TableId(value = "nid", type = IdType.AUTO)
    private int nid; //新闻编号

    private int ntid;//新闻分类编号 外键

    private String ntitle;//新闻标题

    private String nauthor;//新闻作者

    @TableField("ncreateDate")
    private Date ncreateDate;//新闻创建时间

    @TableField("npicPath")
    private String npicPath;

    private String ncontent;//新闻内容

    @TableField("nmodifyDate")
    private Date nmodifyDate;//修改时间

    private String nsummary;//新闻关键字



    @Override
    public String toString() {
        return "News{" +
        "nid=" + nid +
        ", ntid=" + ntid +
        ", ntitle=" + ntitle +
        ", nauthor=" + nauthor +
        ", ncreateDate=" + ncreateDate +
        ", npicPath=" + npicPath +
        ", ncontent=" + ncontent +
        ", nmodifyDate=" + nmodifyDate +
        ", nsummary=" + nsummary +
        "}";
    }
}
