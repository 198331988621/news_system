package com.gzxh.newssystem.controller;

import com.gzxh.newssystem.entity.Users;
import com.gzxh.newssystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/users")
public class UsersController {
    @Autowired
    UserService userService;

    @RequestMapping("/login")
    public String login(String userName, String password, HttpSession session,HttpServletResponse response) {
        Users login = userService.login(userName, password);
        //判定用户是否登录成功
        if (login != null) {

            System.out.println("登录成功!!!!!");
            session.setAttribute("loginUser", login);
        }
        return "redirect:/index.html";
    }
    //退出登录 直接销毁session对象里面的信息
    @RequestMapping("/logout")
    public String logout(HttpSession session){
        //销毁session对象里面的信息
        session.invalidate();
        return "redirect:/index.html";
    }
}
