package com.gzxh.newssystem.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.gzxh.newssystem.entity.News;
import com.gzxh.newssystem.vo.NewsQueryVo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
//表示这个是dao层的访问代码
@Repository
public interface NewsMapper extends BaseMapper<News> {
    //分类查询新闻信息
    @Select("select * from news where ntid = #{topicId} order by ncreateDate desc limit ${number}")
    List<News> getNewsListByTopicId(@Param("topicId") int topicId, @Param("number") int number);

    //分页查询新闻列表 方法名从xml文件复制过来                    分页信息                  分页数量
    IPage<News> getNewsListByPage(@Param("page")IPage<News> page, @Param("news") NewsQueryVo newsQueryVo);
}

