package com.gzxh.newssystem.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.gzxh.newssystem.entity.News;
import com.gzxh.newssystem.vo.NewsQueryVo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


public interface NewsService extends IService<News> {

    public List<News> getNewsListByTopicId(int topicId,int number);

    IPage<News> getNewsListByPage(IPage<News> page, NewsQueryVo newsQueryVo);


    boolean deleteById(Integer nid);
}
