package com.gzxh.newssystem.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.util.Date;
import java.io.Serializable;

@Data
@TableName("comments")
public class Comments implements Serializable {

private static final long serialVersionUID=1L;

    @TableId(value = "cid", type = IdType.AUTO)
    private int  cid; //评论编号

    private int cnid;//新闻编号 外键 跟新闻表关联

    private String ccontent;//评论内容

    private Date cdate;//评论时间

    private String cip;//评论地址

    private String cauthor;//评论人名称




    @Override
    public String toString() {
        return "Comments{" +
        "cid=" + cid +
        ", cnid=" + cnid +
        ", ccontent=" + ccontent +
        ", cdate=" + cdate +
        ", cip=" + cip +
        ", cauthor=" + cauthor +
        "}";
    }
}
