package com.gzxh.newssystem.controller;

import com.gzxh.newssystem.entity.Comments;
import com.gzxh.newssystem.service.CommentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.util.Date;

@Controller
@RequestMapping("/comments")
public class CommentsController {
    @Autowired
    CommentsService commentsService;

    @RequestMapping("/add")
    public String add(Comments comments, HttpServletResponse response){
        comments.setCdate(new Date());
        if (commentsService.save(comments)){
            return "redirect:/news/detail/"+comments.getCnid();//返回true添加成功 重定向回到评论页面
        }
        return "redirect:/news/detail/"+comments.getCnid();
    }
}

