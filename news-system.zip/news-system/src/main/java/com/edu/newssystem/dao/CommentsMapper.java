package com.gzxh.newssystem.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gzxh.newssystem.entity.Comments;

public interface CommentsMapper extends BaseMapper<Comments> {
}
