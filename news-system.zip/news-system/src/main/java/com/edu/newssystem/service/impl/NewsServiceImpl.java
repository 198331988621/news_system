package com.gzxh.newssystem.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gzxh.newssystem.dao.CommentsMapper;
import com.gzxh.newssystem.dao.NewsMapper;
import com.gzxh.newssystem.entity.Comments;
import com.gzxh.newssystem.entity.News;
import com.gzxh.newssystem.service.NewsService;
import com.gzxh.newssystem.vo.NewsQueryVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional //开启数据库事务管理
@Service
public class NewsServiceImpl extends ServiceImpl<NewsMapper, News> implements NewsService {
    @Autowired
    CommentsMapper commentsMapper;
    @Override
    public List<News> getNewsListByTopicId(int topicId, int number) {
        return  baseMapper.getNewsListByTopicId(topicId,number);
    }
    @Override
    public IPage<News> getNewsListByPage(IPage<News> page, NewsQueryVo newsQueryVo) {
        return baseMapper.getNewsListByPage(page,newsQueryVo);
    }

    @Override
    public boolean deleteById(Integer nid) {
        //根据新闻编号来删除新闻信息 但首先要确保新闻的评论也被干掉了
        QueryWrapper<Comments> wrapper=new QueryWrapper<>();
        wrapper.eq("cnid",nid);
        Integer count=commentsMapper.selectCount(wrapper);

        if(count>0){
            int i=commentsMapper.delete(wrapper);
        }

        int delete=baseMapper.deleteById(nid);
        if(delete>0){
            return true;
        }
        return false;
    }
}
