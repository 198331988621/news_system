package com.gzxh.newssystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gzxh.newssystem.dao.UsersMapper;
import com.gzxh.newssystem.entity.Users;
import com.gzxh.newssystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserServiceImpl extends ServiceImpl<UsersMapper, Users> implements UserService {
    @Autowired
    UsersMapper usersMapper;
    //处理用户登录的方法
    @Override
    public Users login(String username, String password) {
        QueryWrapper<Users> wrapper = new QueryWrapper<>();
        wrapper.eq("uname",username);
        wrapper.eq("upwd",password);
        Users users = usersMapper.selectOne(wrapper);
        return users;
    }
}
