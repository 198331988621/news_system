package com.gzxh.newssystem.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gzxh.newssystem.entity.Comments;

public interface CommentsService extends IService<Comments> {
}
