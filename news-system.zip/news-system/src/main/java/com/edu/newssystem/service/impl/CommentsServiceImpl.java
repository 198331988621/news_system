package com.gzxh.newssystem.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gzxh.newssystem.dao.CommentsMapper;
import com.gzxh.newssystem.entity.Comments;
import com.gzxh.newssystem.service.CommentsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
@Service
public class CommentsServiceImpl extends ServiceImpl<CommentsMapper, Comments>implements CommentsService {
    @Override
    public boolean save(Comments entity) {
        return super.save(entity);
    }

}
