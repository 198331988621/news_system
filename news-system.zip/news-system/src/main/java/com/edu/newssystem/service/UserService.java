package com.gzxh.newssystem.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gzxh.newssystem.entity.Users;


public interface UserService extends IService<Users> {
    Users login(String username,String password);
}
