package com.gzxh.newssystem.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.gzxh.newssystem.entity.Topic;
import com.gzxh.newssystem.vo.TopicQueryVo;

public interface TopicService extends IService<Topic> {
}
