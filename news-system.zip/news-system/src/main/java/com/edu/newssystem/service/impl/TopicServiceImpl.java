package com.gzxh.newssystem.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gzxh.newssystem.dao.TopicMapper;
import com.gzxh.newssystem.entity.Topic;
import com.gzxh.newssystem.service.TopicService;
import com.gzxh.newssystem.vo.TopicQueryVo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional //开启数据库事务管理
public class TopicServiceImpl extends ServiceImpl<TopicMapper, Topic> implements TopicService {
}
