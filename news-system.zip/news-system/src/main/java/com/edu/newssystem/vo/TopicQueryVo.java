package com.gzxh.newssystem.vo;

import lombok.Data;

@Data
public class TopicQueryVo {
    private Integer pageNo=1;
    private Integer pageSize=10;
}
