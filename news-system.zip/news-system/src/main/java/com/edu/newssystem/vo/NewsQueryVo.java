package com.gzxh.newssystem.vo;

import lombok.Data;

@Data
public class NewsQueryVo {
    //分类编号
    private Integer ntid;
    //页码
    private Integer pageNo=1;
    //页面数量
    private Integer pageSize=10;
}
