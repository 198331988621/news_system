package com.gzxh.newssystem.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author :
 * @date : 2022/4/24 9:57
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /***
    * @Description:
    * @Param:
    * @return: void
    * @Author:
    * @Date: 2022/4/24
    */
    /**
     * 添加拦截器
     * 添加拦截路径
     * 放行路径
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new LoginInterceptor()).
                addPathPatterns("/**").
                excludePathPatterns("/css/**","/images/**","/js/**","/index.html","/","/users/login");
    }

}
