package com.gzxh.newssystem.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.io.Serializable;

@Data
@TableName("topic")
public class Topic implements Serializable {

private static final long serialVersionUID=1L;

    @TableId(value = "tid", type = IdType.AUTO)
    private int tid;//分类编号 主键

    private String tname;//分类名称



    @Override
    public String toString() {
        return "Topic{" +
        "tid=" + tid +
        ", tname=" + tname +
        "}";
    }
}
