package com.gzxh.newssystem.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gzxh.newssystem.entity.News;
import com.gzxh.newssystem.entity.Topic;
import com.gzxh.newssystem.service.NewsService;
import com.gzxh.newssystem.service.TopicService;
import com.gzxh.newssystem.vo.NewsQueryVo;
import org.apache.ibatis.annotations.Param;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@MapperScan("com.gzxh.newssystem.dao")
@Controller
public class HomeController {
    //注入service层代码
    @Autowired
    NewsService newsService;
    @Autowired
    TopicService topicService;

    @RequestMapping(value = {"/","/index.html","/home.html"})

    public String index(Model model, NewsQueryVo newsQueryVo) {


        //查询出所有分类信息
        List<Topic> topicList = topicService.list();
        model.addAttribute("topicList",topicList);

        //将页码和分页显示的记录数存放到分页对象中
        IPage<News> page=new Page<>(newsQueryVo.getPageNo(),newsQueryVo.getPageSize());
        page = newsService.getNewsListByPage(page, newsQueryVo);
        //获取新闻所有信息 参数传入分页对象和分类id
        model.addAttribute("page",page);
        model.addAttribute("newVo",newsQueryVo);
        //通过视图解析器 去找对应的html模板
        return "index";
    }
}
