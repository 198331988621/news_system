package com.gzxh.newssystem.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.gzxh.newssystem.entity.Topic;
import com.gzxh.newssystem.vo.TopicQueryVo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

@Repository
public interface TopicMapper extends BaseMapper<Topic> {

    @Update("UPDATE topic SET tname=#{tname} WHERE tid = #{tid}")
    public int updateTopic(Topic topic);
}
